## NetSurfP3.0 - results

You can download the results in [.csv format](results.csv) or [.json format](results.json)

To get the result files for individual sequences, please click 'Save Files'
#### >1acb_I
![image](1acb_I.png)
#### >1ay7_A
![image](1ay7_A.png)
